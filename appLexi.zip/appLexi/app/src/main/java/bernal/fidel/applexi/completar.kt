package bernal.fidel.applexi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class completar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.seleccionar)
    }
}