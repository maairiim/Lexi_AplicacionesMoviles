package bernal.fidel.applexi



public class traducir{

}